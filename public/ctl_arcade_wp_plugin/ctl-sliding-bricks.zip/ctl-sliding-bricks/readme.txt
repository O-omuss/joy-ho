=== CTL Sliding Bricks ===
Tags: bricks, ketchapp, skill game, tap game, arcade game, addicting game,trending app, survival game, matching game, colour match, color match, endless game, addictive, slide, sliding game
Requires at least: 4.3
Tested up to: 4.3

Add Sliding Bricks to CTL Arcade plugin

== Description ==
Add Sliding Bricks to CTL Arcade plugin


	